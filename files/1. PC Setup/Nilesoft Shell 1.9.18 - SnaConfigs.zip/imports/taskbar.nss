﻿menu(type="taskbar" pos=0 title=app.name image=\uE249)
{
	item(title="config" image=\uE10A cmd='"@app.cfg"')
	item(title="manager" image=\uE0F3 admin cmd='"@app.exe"')
	item(title="directory" image=\uE0E8 cmd='"@app.dir"')
	item(title="version\t"+@app.ver vis=label col=1)
	item(title="docs" image=\uE1C4 cmd='https://nilesoft.org/docs')
	item(title="donate" image=\uE1A7 cmd='https://nilesoft.org/donate')
}

menu(where=@(this.count == 0) type='taskbar' image=icon.settings expanded=true)
{
	//menu(title="Apps" image=\uE254)
	//{
		//item(title='Paint' image=\uE116 cmd='mspaint')
		//item(title='Edge' image cmd='@sys.prog32\Microsoft\Edge\Application\msedge.exe')
		//item(title='Calculator' image=\ue1e7 cmd='calc.exe')
		//item(title=str.res('regedit.exe,-16') image cmd='regedit.exe')
	//}
	//menu(title=title.windows image=\uE1FB)
	//{
		//item(title=title.cascade_windows cmd=command.cascade_windows)
		//item(title=title.Show_windows_stacked cmd=command.Show_windows_stacked)
		//item(title=title.Show_windows_side_by_side cmd=command.Show_windows_side_by_side)
		//sep
		//item(title=title.minimize_all_windows cmd=command.minimize_all_windows)
		//item(title=title.restore_all_windows cmd=command.restore_all_windows)
	//}
	
	
	item(title=title.run image=\uE14B cmd='shell:::{2559a1f3-21d7-11d4-bdaf-00c04f60b9f0}')
	item(title=@str.res('regedit.exe,-16') image cmd='regedit.exe')
	item(title='Restart Explorer'image=\uE0CE cmd=command.restart_explorer)
	sep
	item(title=title.task_manager image=icon.task_manager cmd='taskmgr.exe')
	item(title=title.settings image=icon.settings(auto, image.color1) cmd='ms-settings:')
	item(vis=key.shift() title=title.exit_explorer cmd=command.restart_explorer)
}