﻿settings
{
	priority=1
	exclude.where = !process.is_explorer
	showdelay = 200
	// Options to allow modification of system items
	modify.remove.duplicate=1
	tip.enabled=true
}

import 'imports/theme.nss'
import 'imports/images.nss'

import 'imports/modify.nss'

sep

menu(mode="multiple" title=title.more_options image=icon.more_options)
{
}


menu(title='New + shortcut      ' image=\uE14B)
		{
		item(title='Open Desktop' pos=0 image=\uE1F4 cmd=user.desktop)	
		item(title='Copy Path' image=icon.copy_path tip=sel.path cmd=command.copy(sel.path))
		
		item(title='New Folder' image=icon.new_folder cmd=io.dir.create('New Folder ' + sys.datetime("HMS")))
		
		$dt = 'New Text Document ' + sys.datetime("HMS")
		item(title='Text Document' image=icon.new_file cmd=io.file.create('@(dt).txt', ''))	
		}


modify(mode=mode.multiple where=this.title.length > 15 pos=top menu=title.more_options)


menu(mode="multiple" title="Pin/Unpin" image=icon.pin)
{
}

import 'imports/terminal.nss'
//import 'imports/file-manage.nss'
//import 'imports/develop.nss'
//import 'imports/goto.nss'
import 'imports/taskbar.nss'

item(title=title.control_panel menu=title.more_options image=\uE0F3 cmd='shell:::{5399E694-6CE5-4D6C-8FCE-1D8870FDCBA0}')		
		
item(title='Network Connections' menu=title.more_options image=\uE0F3 cmd='shell:::{7007ACC7-3202-11D1-AAD2-00805FC1270E}')

//sep
//item(where=sys.ver.major >= 10 title='Open in Terminal' tip=tip_run_admin admin=key.shift() //image='@package.path("WindowsTerminal")\WindowsTerminal.exe' cmd='wt.exe' arg='-d "@sel.path\."')		
